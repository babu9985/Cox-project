import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HomeComponent } from './home/home.component';
import { LayoutComponent } from './layout/layout.component';
import { IvrComponent } from './ivr/ivr.component';
import { DynamicMessageComponent } from './ivr/dynamic-message/dynamic-message.component';
import { DnisComponent } from './ivr/dnis/dnis.component';
import { ExitToMapComponent } from './ivr/exit-to-map/exit-to-map.component';
import { FlagsAdminComponent } from './ivr/flags-admin/flags-admin.component';
import { OfficeLocatorComponent } from './ivr/office-locator/office-locator.component';
import { PayPerViewComponent } from './ivr/pay-per-view/pay-per-view.component';
import { GetCampaignComponent } from './ivr/get-campaign/get-campaign.component';
import { BridgeApplicationComponent } from './ivr/bridge-application/bridge-application.component';
import { MessageAdministrationComponent } from './ivr/message-administration/message-administration.component';
import { TechnicianAdministrationComponent } from './ivr/technician-administration/technician-administration.component';
import { IvrExitRulesComponent } from './ivr/ivr-exit-rules/ivr-exit-rules.component';
import { CprComponent } from './cpr/cpr.component';
import { AngularMaterialRouting } from './angular-material-routing';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LayoutComponent,
    IvrComponent,
    DynamicMessageComponent,
    DnisComponent,
    ExitToMapComponent,
    FlagsAdminComponent,
    OfficeLocatorComponent,
    PayPerViewComponent,
    GetCampaignComponent,
    BridgeApplicationComponent,
    MessageAdministrationComponent,
    TechnicianAdministrationComponent,
    IvrExitRulesComponent,
    CprComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularMaterialRouting,
    BrowserAnimationsModule,
    FormsModule,
    FlexLayoutModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
