import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpr',
  templateUrl: './cpr.component.html',
  styleUrls: ['./cpr.component.css']
})
export class CprComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
