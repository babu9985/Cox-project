import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CprComponent } from './cpr.component';

const routes: Routes = [
  {
    path: '',
    component: CprComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CprRoutingModule { }
