import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CprRoutingModule } from './cpr-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CprRoutingModule
  ]
})
export class CprModule { }
