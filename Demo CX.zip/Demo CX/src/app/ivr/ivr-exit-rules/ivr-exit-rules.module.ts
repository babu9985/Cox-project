import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IvrExitRulesRoutingModule } from './ivr-exit-rules-routing.module';
import { ExitPointRulesComponent } from './exit-point-rules/exit-point-rules.component';
import { EarlyExitRulesComponent } from './early-exit-rules/early-exit-rules.component';
import { DynamicRulesOneComponent } from './dynamic-rules-one/dynamic-rules-one.component';
import { DynamicRulesTwoComponent } from './dynamic-rules-two/dynamic-rules-two.component';


@NgModule({
  declarations: [ExitPointRulesComponent, EarlyExitRulesComponent, DynamicRulesOneComponent, DynamicRulesTwoComponent],
  imports: [
    CommonModule,
    IvrExitRulesRoutingModule
  ]
})
export class IvrExitRulesModule { }
