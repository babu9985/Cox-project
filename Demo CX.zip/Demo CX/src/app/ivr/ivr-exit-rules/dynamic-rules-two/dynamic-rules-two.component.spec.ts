import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicRulesTwoComponent } from './dynamic-rules-two.component';

describe('DynamicRulesTwoComponent', () => {
  let component: DynamicRulesTwoComponent;
  let fixture: ComponentFixture<DynamicRulesTwoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicRulesTwoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicRulesTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
