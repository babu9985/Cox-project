import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-rules-two',
  templateUrl: './dynamic-rules-two.component.html',
  styleUrls: ['./dynamic-rules-two.component.css']
})
export class DynamicRulesTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
