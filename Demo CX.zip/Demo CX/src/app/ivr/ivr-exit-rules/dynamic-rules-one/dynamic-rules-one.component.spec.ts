import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicRulesOneComponent } from './dynamic-rules-one.component';

describe('DynamicRulesOneComponent', () => {
  let component: DynamicRulesOneComponent;
  let fixture: ComponentFixture<DynamicRulesOneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicRulesOneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicRulesOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
