import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-rules-one',
  templateUrl: './dynamic-rules-one.component.html',
  styleUrls: ['./dynamic-rules-one.component.css']
})
export class DynamicRulesOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
