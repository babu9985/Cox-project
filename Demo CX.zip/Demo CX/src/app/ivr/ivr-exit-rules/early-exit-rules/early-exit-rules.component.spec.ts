import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EarlyExitRulesComponent } from './early-exit-rules.component';

describe('EarlyExitRulesComponent', () => {
  let component: EarlyExitRulesComponent;
  let fixture: ComponentFixture<EarlyExitRulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EarlyExitRulesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EarlyExitRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
