import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-early-exit-rules',
  templateUrl: './early-exit-rules.component.html',
  styleUrls: ['./early-exit-rules.component.css']
})
export class EarlyExitRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
