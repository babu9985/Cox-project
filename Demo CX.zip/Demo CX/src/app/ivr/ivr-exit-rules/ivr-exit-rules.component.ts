import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ivr-exit-rules',
  templateUrl: './ivr-exit-rules.component.html',
  styleUrls: ['./ivr-exit-rules.component.css']
})
export class IvrExitRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
