import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExitPointRulesComponent } from './exit-point-rules/exit-point-rules.component';

const routes: Routes = [
  {
    path: '',
    component: ExitPointRulesComponent
  },
  {
    path: 'exitrules',
    component: ExitPointRulesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IvrExitRulesRoutingModule { }
