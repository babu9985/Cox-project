import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exit-point-rules',
  templateUrl: './exit-point-rules.component.html',
  styleUrls: ['./exit-point-rules.component.css']
})
export class ExitPointRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
