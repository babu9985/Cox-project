import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExitPointRulesComponent } from './exit-point-rules.component';

describe('ExitPointRulesComponent', () => {
  let component: ExitPointRulesComponent;
  let fixture: ComponentFixture<ExitPointRulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExitPointRulesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExitPointRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
