import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bridge-application',
  templateUrl: './bridge-application.component.html',
  styleUrls: ['./bridge-application.component.css']
})
export class BridgeApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
