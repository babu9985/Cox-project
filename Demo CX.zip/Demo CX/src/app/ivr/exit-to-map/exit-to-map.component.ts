import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exit-to-map',
  templateUrl: './exit-to-map.component.html',
  styleUrls: ['./exit-to-map.component.css']
})
export class ExitToMapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
