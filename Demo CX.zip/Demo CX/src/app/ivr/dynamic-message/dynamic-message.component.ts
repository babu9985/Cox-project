import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-message',
  templateUrl: './dynamic-message.component.html',
  styleUrls: ['./dynamic-message.component.css']
})
export class DynamicMessageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
