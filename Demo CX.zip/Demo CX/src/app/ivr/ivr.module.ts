import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IvrRoutingModule } from './ivr-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    IvrRoutingModule
  ]
})
export class IvrModule { }
