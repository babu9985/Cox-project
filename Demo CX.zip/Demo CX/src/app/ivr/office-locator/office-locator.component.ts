import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-office-locator',
  templateUrl: './office-locator.component.html',
  styleUrls: ['./office-locator.component.css']
})
export class OfficeLocatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
