import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technician-administration',
  templateUrl: './technician-administration.component.html',
  styleUrls: ['./technician-administration.component.css']
})
export class TechnicianAdministrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
