import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-per-view',
  templateUrl: './pay-per-view.component.html',
  styleUrls: ['./pay-per-view.component.css']
})
export class PayPerViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
