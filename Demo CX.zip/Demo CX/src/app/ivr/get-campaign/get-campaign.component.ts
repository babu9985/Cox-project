import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-campaign',
  templateUrl: './get-campaign.component.html',
  styleUrls: ['./get-campaign.component.css']
})
export class GetCampaignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
