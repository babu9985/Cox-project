import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dnis',
  templateUrl: './dnis.component.html',
  styleUrls: ['./dnis.component.css']
})
export class DnisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
