import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flags-admin',
  templateUrl: './flags-admin.component.html',
  styleUrls: ['./flags-admin.component.css']
})
export class FlagsAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
