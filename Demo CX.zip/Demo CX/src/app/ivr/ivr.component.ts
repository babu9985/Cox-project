import { Component, OnInit } from '@angular/core';
import { Router, Routes } from '@angular/router';

@Component({
  selector: 'app-ivr',
  templateUrl: './ivr.component.html',
  styleUrls: ['./ivr.component.css']
})
export class IvrComponent implements OnInit {

  constructor(private router: Router) { }

  backResults(){
    this.router.navigateByUrl('');
  }

  ngOnInit(): void {
  }

}
