import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-message-administration',
  templateUrl: './message-administration.component.html',
  styleUrls: ['./message-administration.component.css']
})
export class MessageAdministrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
