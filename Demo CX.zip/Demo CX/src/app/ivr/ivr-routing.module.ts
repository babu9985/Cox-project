import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IvrComponent } from './ivr.component';

const routes: Routes = [
  {
    path: '',
    component: IvrComponent,
    loadChildren: () => import('./../ivr/ivr-exit-rules/ivr-exit-rules-routing.module')
    .then(mod=>mod.IvrExitRulesRoutingModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IvrRoutingModule { }
