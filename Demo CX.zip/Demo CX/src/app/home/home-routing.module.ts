import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '', loadChildren: () => import('./../ivr/ivr.module')
    .then(mod=>mod.IvrModule)
  },
  {
    path: 'IVR', loadChildren: () => import('./../ivr/ivr.module')
    .then(mod=>mod.IvrModule)
  },
  {
    path: 'CPR', loadChildren: () => import('./../cpr/cpr.module')
    .then(mod=>mod.CprModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
